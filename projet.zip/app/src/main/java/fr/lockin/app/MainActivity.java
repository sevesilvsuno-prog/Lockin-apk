package fr.lockin.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class MainActivity extends Activity {
  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    getWindow().setStatusBarColor(Color.parseColor("#0b0d10"));
    getWindow().setNavigationBarColor(Color.parseColor("#0b0d10"));

    WebView wv = new WebView(this);
    WebSettings s = wv.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);                 // persistance localStorage
    s.setMediaPlaybackRequiresUserGesture(false); // bip du minuteur
    wv.setWebChromeClient(new WebChromeClient());
    wv.setBackgroundColor(Color.parseColor("#0b0d10"));
    wv.loadUrl("file:///android_asset/index.html");
    setContentView(wv);
  }
  @Override public void onBackPressed() { moveTaskToBack(true); }
}
